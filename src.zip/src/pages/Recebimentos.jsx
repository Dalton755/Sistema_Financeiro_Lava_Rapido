import { useEffect, useState } from "react";

import RecebimentoCard
    from "../components/recebimentos/RecebimentoCard";

import { listarRecebimentos }
    from "../services/recebimentos";

import PageContainer
    from "../components/ui/PageContainer";

import PageHeader
    from "../components/ui/PageHeader";

import SummaryCard
    from "../components/ui/SummaryCard";

import EmptyState
    from "../components/ui/EmptyState";

import {
    formatarMoeda
} from "../lib/formatadores";

export default function Recebimentos() {

    const [

        recebimentos,

        setRecebimentos

    ] = useState([]);

    useEffect(() => {

        carregar();

    }, []);

    async function carregar() {

        try {

            const dados =
                await listarRecebimentos();

            setRecebimentos(dados);

        } catch (error) {

            console.error(error);

        }

    }

    const quantidadeRecebimentos =
        recebimentos.length;

    const quantidadeNotas =
        recebimentos.reduce(

            (total, item) =>

                total + item.quantidadeNotas,

            0

        );

    const valorTotal =
        recebimentos.reduce(

            (total, item) =>

                total + item.valorTotal,

            0

        );

    return (

        <PageContainer>

            <PageHeader

                title="Recebimentos"

                subtitle="Confirme os pagamentos importados automaticamente."

            />

            <div className="row g-3 mb-4">

                <div className="col-md-4">

                    <SummaryCard
                        title="Pendentes"
                        value={quantidadeRecebimentos}
                        icon="bi bi-hourglass-split"
                        color="warning"
                    />

                </div>

                <div className="col-md-4">

                    <SummaryCard
                        title="Notas"
                        value={quantidadeNotas}
                        icon="bi bi-receipt"
                        color="primary"
                    />

                </div>

                <div className="col-md-4">

                    <SummaryCard
                        title="Valor Pendente"
                        value={formatarMoeda(valorTotal)}
                        icon="bi bi-cash-stack"
                        color="success"
                    />

                </div>

            </div>

            {

                recebimentos.length === 0

                    ?

                    (

                        <EmptyState

                            title="Nenhum recebimento pendente"

                            description="Todos os pagamentos importados já foram confirmados."

                        />

                    )

                    :

                    (

                        recebimentos.map(recebimento => (

                            <RecebimentoCard

                                key={recebimento.messageId}

                                recebimento={recebimento}

                            />

                        ))

                    )

            }

        </PageContainer>

    );

}